'use client'

import { useState, useRef, useEffect } from 'react'
import { Upload, AlertCircle, Download, Trash2, Play } from 'lucide-react'
import { PolygonCanvas } from '@/components/video/polygon-canvas'

interface Zone {
  id: number
  points: Array<[number, number]>
  frameIndex: number
  name: string
}

export function VideoUploadPage() {
  const [videoFile, setVideoFile] = useState<File | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState<'upload' | 'drawing' | 'preview'>('upload')
  const [zones, setZones] = useState<Zone[]>([])
  const [currentZone, setCurrentZone] = useState(1)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file)
      const url = URL.createObjectURL(file)
      setVideoUrl(url)
      setStep('drawing')
      setZones([])
    }
  }

  const handleDownloadConfig = () => {
    const config = zones.map(z => z.points)
    const dataStr = JSON.stringify(config, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'zone-config.json'
    link.click()
  }

  const handleZoneComplete = (points: Array<[number, number]>) => {
    const newZone: Zone = {
      id: currentZone,
      points,
      frameIndex: 1,
      name: `Zone ${currentZone}`
    }
    setZones([...zones, newZone])
    if (currentZone < 3) {
      setCurrentZone(currentZone + 1)
    }
  }

  const handleRemoveZone = (id: number) => {
    setZones(zones.filter(z => z.id !== id))
  }

  return (
    <div className="space-y-6 pb-24 lg:pb-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Zone Configuration</h1>
        <p className="text-muted-foreground">Upload a video and define detection zones for queue monitoring</p>
      </div>

      {step === 'upload' && (
        <>
          {/* Upload Section */}
          <div className="bg-card rounded-lg border border-border p-8">
            <div className="border-2 border-dashed border-border rounded-lg p-12 text-center hover:border-primary/50 transition-colors cursor-pointer"
              onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="font-semibold mb-2">Upload Video File</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Drag and drop your video or click to browse (MP4, MOV, AVI)
              </p>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={handleVideoUpload}
              />
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  fileInputRef.current?.click()
                }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
              >
                Select Video
              </button>
            </div>
          </div>

          {/* Info Section */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold mb-2">Zone Drawing Guide</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Upload a video showing your queue area</li>
                  <li>• Draw custom polygons on 3 key frames to define detection zones</li>
                  <li>• Configure up to 3 different zones per video</li>
                  <li>• JSON config will be used by YOLO for detection</li>
                </ul>
              </div>
            </div>
          </div>
        </>
      )}

      {step === 'drawing' && videoUrl && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PolygonCanvas
                videoUrl={videoUrl}
                zoneNumber={currentZone}
                onComplete={handleZoneComplete}
                maxZones={3}
                existingZonesCount={zones.length}
              />
            </div>

            <div className="space-y-4">
              <div className="bg-card rounded-lg border border-border p-6">
                <h3 className="font-semibold mb-4">Configured Zones</h3>
                <div className="space-y-2">
                  {zones.map((zone) => (
                    <div key={zone.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{zone.name}</p>
                        <p className="text-xs text-muted-foreground">{zone.points.length} points</p>
                      </div>
                      <button
                        onClick={() => handleRemoveZone(zone.id)}
                        className="p-1 hover:bg-destructive/10 text-destructive rounded transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-card rounded-lg border border-border p-6">
                <h4 className="font-semibold mb-3">Instructions</h4>
                <ol className="text-sm text-muted-foreground space-y-2">
                  <li>1. <strong>Click</strong> on video to add points</li>
                  <li>2. <strong>Double-click</strong> to complete zone</li>
                  <li>3. Create up to 3 zones</li>
                  <li>4. Download JSON config</li>
                </ol>
              </div>

              {zones.length > 0 && (
                <button
                  onClick={handleDownloadConfig}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-semibold"
                >
                  <Download className="w-4 h-4" />
                  Download Config
                </button>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
