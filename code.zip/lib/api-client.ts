'use client'

// API client for communicating with FastAPI backend
// Configure NEXT_PUBLIC_API_URL in your environment variables

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

class ApiClient {
  private baseUrl: string

  constructor(baseUrl: string = API_URL) {
    this.baseUrl = baseUrl
  }

  async fetch<T = any>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const url = `${this.baseUrl}${endpoint}`
      console.log('[API] Calling', url)

      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      })

      if (!response.ok) {
        console.error('[API] Error:', response.status, response.statusText)
        return {
          success: false,
          error: `${response.status}: ${response.statusText}`,
        }
      }

      const data = await response.json()
      console.log('[API] Response:', data)
      return {
        success: true,
        data,
      }
    } catch (error) {
      console.error('[API] Exception:', error)
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      }
    }
  }

  get<T = any>(endpoint: string, options?: RequestInit) {
    return this.fetch<T>(endpoint, { method: 'GET', ...options })
  }

  post<T = any>(endpoint: string, body?: any, options?: RequestInit) {
    return this.fetch<T>(endpoint, {
      method: 'POST',
      body: body ? JSON.stringify(body) : undefined,
      ...options,
    })
  }

  put<T = any>(endpoint: string, body?: any, options?: RequestInit) {
    return this.fetch<T>(endpoint, {
      method: 'PUT',
      body: body ? JSON.stringify(body) : undefined,
      ...options,
    })
  }

  delete<T = any>(endpoint: string, options?: RequestInit) {
    return this.fetch<T>(endpoint, { method: 'DELETE', ...options })
  }
}

export const apiClient = new ApiClient()

// Queue Management API
export const queueApi = {
  getMetrics: (timeRange = '1h') =>
    apiClient.get('/api/queue/metrics', {
      method: 'GET',
      headers: { 'X-Time-Range': timeRange },
    }),

  getQueues: () => apiClient.get('/api/queues'),

  getQueueById: (queueId: string) => apiClient.get(`/api/queues/${queueId}`),

  getZoneStats: (zoneId: number) =>
    apiClient.get(`/api/zones/${zoneId}/stats`),

  processZoneConfig: (config: any) =>
    apiClient.post('/api/zones/config', config),
}

// Video Processing API
export const videoApi = {
  uploadVideo: (formData: FormData) =>
    apiClient.fetch('/api/video/upload', {
      method: 'POST',
      body: formData,
      headers: { 'Content-Type': 'multipart/form-data' },
    }),

  processVideo: (videoId: string, zoneConfig: any) =>
    apiClient.post(`/api/video/${videoId}/process`, { zoneConfig }),

  getProcessingStatus: (videoId: string) =>
    apiClient.get(`/api/video/${videoId}/status`),
}

// Detection API
export const detectionApi = {
  startDetection: (videoId: string, zoneConfig: any) =>
    apiClient.post(`/api/detection/start`, { videoId, zoneConfig }),

  stopDetection: (detectionId: string) =>
    apiClient.post(`/api/detection/${detectionId}/stop`),

  getDetectionResults: (detectionId: string) =>
    apiClient.get(`/api/detection/${detectionId}/results`),

  getLiveDetectionStream: (detectionId: string) =>
    `${API_URL}/api/detection/${detectionId}/stream`,
}

// Employee API
export const employeeApi = {
  getEmployees: () => apiClient.get('/api/employees'),

  createEmployee: (employee: any) =>
    apiClient.post('/api/employees', employee),

  updateEmployee: (id: string, employee: any) =>
    apiClient.put(`/api/employees/${id}`, employee),

  deleteEmployee: (id: string) => apiClient.delete(`/api/employees/${id}`),

  updateAvailability: (id: string, availability: string) =>
    apiClient.put(`/api/employees/${id}/availability`, { availability }),
}

// Notifications API
export const notificationsApi = {
  getNotifications: () => apiClient.get('/api/notifications'),

  createNotification: (notification: any) =>
    apiClient.post('/api/notifications', notification),

  markAsRead: (id: string) =>
    apiClient.put(`/api/notifications/${id}/read`),

  deleteNotification: (id: string) =>
    apiClient.delete(`/api/notifications/${id}`),
}

// WebSocket for real-time updates
export class QueueWebSocket {
  private ws: WebSocket | null = null
  private url: string
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private listeners: Map<string, Function[]> = new Map()

  constructor(url = `${API_URL.replace('http', 'ws')}/api/ws`) {
    this.url = url
  }

  connect() {
    try {
      console.log('[WebSocket] Connecting to', this.url)
      this.ws = new WebSocket(this.url)

      this.ws.onopen = () => {
        console.log('[WebSocket] Connected')
        this.reconnectAttempts = 0
      }

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          console.log('[WebSocket] Message received:', data)
          this.emit(data.type, data.payload)
        } catch (error) {
          console.error('[WebSocket] Parse error:', error)
        }
      }

      this.ws.onerror = (error) => {
        console.error('[WebSocket] Error:', error)
      }

      this.ws.onclose = () => {
        console.log('[WebSocket] Disconnected')
        this.attemptReconnect()
      }
    } catch (error) {
      console.error('[WebSocket] Connection failed:', error)
      this.attemptReconnect()
    }
  }

  private attemptReconnect() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++
      const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000)
      console.log(`[WebSocket] Attempting reconnect in ${delay}ms`)
      setTimeout(() => this.connect(), delay)
    }
  }

  send(type: string, payload: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload }))
    } else {
      console.warn('[WebSocket] Not connected, cannot send message')
    }
  }

  on(event: string, callback: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, [])
    }
    this.listeners.get(event)!.push(callback)
  }

  off(event: string, callback: Function) {
    const listeners = this.listeners.get(event)
    if (listeners) {
      this.listeners.set(
        event,
        listeners.filter((cb) => cb !== callback)
      )
    }
  }

  private emit(event: string, data: any) {
    const listeners = this.listeners.get(event) || []
    listeners.forEach((cb) => cb(data))
  }

  disconnect() {
    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
  }
}

export const queueWs = new QueueWebSocket()
